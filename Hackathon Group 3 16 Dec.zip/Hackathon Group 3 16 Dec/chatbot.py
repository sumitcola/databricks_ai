# Databricks notebook source
!pip install spacy
!pip install textblob
!pip install googletrans
!pip install openai
!pip install chromadb transformers

# COMMAND ----------

!python -m spacy download en_core_web_sm

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import torch
import chromadb
from PIL import Image
from transformers import CLIPProcessor, CLIPModel
from sklearn.metrics.pairwise import cosine_similarity
import time
import os
import numpy as np
from transformers import MarianMTModel, MarianTokenizer, pipeline
import spacy
from textblob import TextBlob

# COMMAND ----------

client = chromadb.Client()
collection = client.create_collection("image_collection")

model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

folder_path = './Images_for_db'  # Use Databricks filesystem path

# Get all image files from the folder
image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp','.jfif']  # Add more extensions if needed
image_paths = [os.path.join(folder_path, f) for f in os.listdir(folder_path) 
            if os.path.splitext(f)[1].lower() in image_extensions]

# Load and preprocess images
images = [Image.open(image_path).resize((100, 100)) for image_path in image_paths]
inputs = processor(images=images, return_tensors="pt", padding=True)

start_ingestion_time = time.time()
with torch.no_grad():
    image_embeddings = model.get_image_features(**inputs).numpy()
image_embeddings = [embedding.tolist() for embedding in image_embeddings]
end_ingestion_time = time.time()
ingestion_time = end_ingestion_time - start_ingestion_time

# Add embeddings to the ChromaDB collection
collection.add(
    embeddings=image_embeddings,
    metadatas=[{"image": image_path} for image_path in image_paths],
    ids=[str(i) for i in range(len(image_paths))],
)
print(f"Image ingestion completed in {ingestion_time:.4f} seconds")

# print(image_paths)
# print(len(image_paths))

# COMMAND ----------

# Load spaCy model for named entity recognition
nlp = spacy.load("en_core_web_sm")

# Load Hugging Face image classification pipeline
image_pipeline = pipeline("image-classification")

def classify_sentiment(prompt):
    """Classify sentiment as Positive or Negative."""
    analysis = TextBlob(prompt)
    sentiment = "Positive" if analysis.sentiment.polarity > 0 else "Negative"
    return sentiment

def extract_named_entities(prompt):
    """Extract named entities from the prompt."""
    doc = nlp(prompt)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    return entities

def identify_request_type(prompt):
    """Identify if the request is for text, image, or translation."""
    prompt_lower = prompt.lower()
    if "image" in prompt_lower or "picture" in prompt_lower:
        return "image"
    elif prompt_lower.startswith("translate to"):
        return "translation"
    else:
        return "text"

def calculate_accuracy(image_embedding, query_embedding):
    similarity = cosine_similarity([image_embedding], [query_embedding])[0][0]
    return similarity

# Step 7: Define a text-to-image search function
def search_image(query):
    print(f"\nQuery: {query}")
    start_time = time.time()

    # Generate query embedding
    inputs = processor(text=query, return_tensors="pt", padding=True)
    with torch.no_grad():
        query_embedding = model.get_text_features(**inputs).numpy()
    query_embedding = query_embedding.tolist()

    # Perform vector search in ChromaDB
    results = collection.query(
        query_embeddings=query_embedding,
        n_results=1,
    )

    # Retrieve matched image and calculate accuracy
    result_image_path = results["metadatas"][0][0]["image"]
    matched_image_index = int(results["ids"][0][0])
    matched_image_embedding = image_embeddings[matched_image_index]
    accuracy_score = calculate_accuracy(matched_image_embedding, query_embedding[0])

    query_time = time.time() - start_time
    print(f"Query processed in {query_time:.4f} seconds with accuracy: {accuracy_score:.4f}")

    captions = [
            f"Generated image based on the prompt: {query}",
            "This image was created using AI based on your request.",
            "An artistic interpretation of the described scene."
        ]

    # Display the result
    result_image = Image.open(result_image_path)
    return result_image, captions, accuracy_score, query_time

def translate_to_language(text, target_language):
    """Translate text to specified language (French, Spanish, or German)."""
    if not text:
        return None
    model_name = f"Helsinki-NLP/opus-mt-en-{target_language}"
    tokenizer = MarianTokenizer.from_pretrained(model_name)
    model = MarianMTModel.from_pretrained(model_name)

    # Tokenize input text
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)
    translated = model.generate(**inputs)
    translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
    return translated_text

def chatbot():
    """Chatbot loop that processes input and performs tasks."""
    print("Chatbot is running. Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == 'exit':
            print("Goodbye!")
            break

        # Identify request type
        request_type = identify_request_type(user_input)

        if request_type == "image":
            # Generate image and captions
            result_image, captions, accuracy, query_time = search_image(user_input)
            print(f"Accuracy: {accuracy:.4f}, Query Time: {query_time:.4f}")
            display(result_image)
            print("Captions:")
            for caption in captions:
                print(f"  - {caption}")
            break
        elif request_type == "translation":
            # Extract text and target language
            lang_map = {
                "french": "fr",
                "spanish": "es",
                "german": "de"
            }
            tokens = user_input.split("\"")
            if len(tokens) >= 2:
                target_language = tokens[0].split("to")[1].strip().lower()
                text_to_translate = tokens[1].strip()
                if target_language in lang_map:
                    # Translate to specified language
                    translation = translate_to_language(text_to_translate, lang_map[target_language])
                    print(f"Translation to {target_language.capitalize()}: {translation}")
                else:
                    print("Unsupported language. Supported languages: French, Spanish, German.")
        
        else:
            # Classify sentiment
            sentiment = classify_sentiment(user_input)
            print(f"Sentiment: {sentiment}")

            # Extract named entities
            entities = extract_named_entities(user_input)
            if entities:
                print("Named Entities:")
                for entity, label in entities:
                    print(f"  - {entity} ({label})")
            else:
                print("No named entities found.")

if __name__ == "__main__":
    chatbot()


# COMMAND ----------

